package com.training;

public class SplitMethod {

}
