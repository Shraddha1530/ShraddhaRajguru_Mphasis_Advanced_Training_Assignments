module ProblemStatement1 {
}